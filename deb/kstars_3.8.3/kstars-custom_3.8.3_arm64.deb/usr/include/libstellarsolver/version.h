/* Version information */
#define StellarSolver_VERSION "2.6"

/* Build TS */
#define StellarSolver_BUILD_TS "2026-07-27T03:12:36Z"
